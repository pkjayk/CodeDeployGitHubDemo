**To delete an API within the specified region**

Command::

  aws apigateway delete-rest-api --rest-api-id 1234123412 --region us-west-2

