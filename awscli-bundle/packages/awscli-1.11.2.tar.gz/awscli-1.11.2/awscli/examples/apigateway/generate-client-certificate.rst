**To create a Client-Side SSL Certificate in the specified region**

Command::

  aws apigateway generate-client-certificate --description 'My First Client Certificate' --region us-west-2

