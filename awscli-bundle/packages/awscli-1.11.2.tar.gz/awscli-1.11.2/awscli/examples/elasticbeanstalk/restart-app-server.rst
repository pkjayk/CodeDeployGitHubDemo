**To restart application servers**

The following command restarts application servers on all instances in an environment named ``my-env``::

  aws elasticbeanstalk restart-app-server --environment-name my-env
